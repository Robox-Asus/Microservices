package com.hotel.hotelservice.services;

import com.hotel.hotelservice.entities.Hotel;
import com.hotel.hotelservice.exceptions.HotelNotFoundException;
import com.hotel.hotelservice.interfaces.IHotelService;
import com.hotel.hotelservice.repository.HotelRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HotelService implements IHotelService {

    private final HotelRepository _hotelRepository;

    public HotelService(HotelRepository hotelRepository){
        this._hotelRepository = hotelRepository;
    }

    @Override
    public Hotel createHotel(Hotel hotel) {
        return this._hotelRepository.save(hotel);
    }

    @Override
    public List<Hotel> getAllHotel() {
        return this._hotelRepository.findAll();
    }

    @Override
    public Hotel getSingleHotel(String hotelId) {
        return this._hotelRepository.findById(hotelId).orElseThrow(() -> new HotelNotFoundException("Hotel with the given : "+hotelId+" Not Found ..."));
    }
}
