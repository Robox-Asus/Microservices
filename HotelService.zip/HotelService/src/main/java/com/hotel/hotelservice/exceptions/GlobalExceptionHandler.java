package com.hotel.hotelservice.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private final Map<String,Object> map = new HashMap<>();
    @ExceptionHandler(HotelNotFoundException.class)
    public ResponseEntity<Map<String,Object>> resourceHotelNotFoundException(HotelNotFoundException ex) {
       map.put("message",ex.getMessage());
       map.put("success",false);
       map.put("status",HttpStatus.NOT_FOUND);
       return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String,Object>> globalExceptionHandler(Exception ex) {
        map.put("message",ex.getMessage());
        map.put("success",false);
        map.put("status",HttpStatus.NOT_FOUND);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
    }
}
