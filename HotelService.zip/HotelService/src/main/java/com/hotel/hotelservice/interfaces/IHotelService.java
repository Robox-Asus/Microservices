package com.hotel.hotelservice.interfaces;

import com.hotel.hotelservice.entities.Hotel;

import java.util.List;

public interface IHotelService {
    //create
    Hotel createHotel(Hotel hotel);

    //getAll
    List<Hotel> getAllHotel();

    //getSingleHotel
    Hotel getSingleHotel(String hotelId);
}
