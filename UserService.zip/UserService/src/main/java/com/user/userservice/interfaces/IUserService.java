package com.user.userservice.interfaces;

import com.user.userservice.entities.User;
import java.util.List;

public interface IUserService {

    //create a single user record
    User saveUser(User user);
    //get All User Record
    List<User> getAllUser();
    //get a single user record
    User getUser(String userId);
    // delete a single record
    String deleteRecord(String userId);
    // update a single record
    String updateRecord(String userId,User user);

}
