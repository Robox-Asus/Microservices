package com.user.userservice.services;

import com.user.userservice.External.HotelService;
import com.user.userservice.External.RatingService;
import com.user.userservice.entities.Hotel;
import com.user.userservice.entities.Rating;
import com.user.userservice.entities.User;
import com.user.userservice.exception.UserNotFoundException;
import com.user.userservice.interfaces.IUserService;
import com.user.userservice.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class UserService implements IUserService {
    private final UserRepository _userRepository;
    private final RestTemplate _restTemplate;
    private final HotelService _hotelService;
    private final Logger logger = LoggerFactory.getLogger(UserService.class);

    public UserService(UserRepository userRepository,RestTemplate restTemplate,HotelService hotelService) {
        this._userRepository = userRepository;
        this._restTemplate = restTemplate;
        this._hotelService = hotelService;
    }

    @Override
    public User saveUser(User user) {
        return this._userRepository.save(user);
    }

    @Override
    public List<User> getAllUser() {
        return this._userRepository.findAll();
    }

    @Override
    public User getUser(String userId) {
        User user = this._userRepository.findById(userId).orElseThrow(() -> new UserNotFoundException("User with given Id : " + userId + " not found the server"));
        // fetching rating by userId
        logger.info("calling rating service method");
        Rating[] ratings = this._restTemplate.getForObject("http://RATING-SERVICE/ratings/users/"+user.getUserId(),Rating[].class);
        logger.info("{}", (Object[]) ratings);
        List<Rating> ratingOfUser = Arrays.stream(Objects.requireNonNull(ratings)).toList();
        logger.info("{}",ratingOfUser);

//        when you don't want to use Rest Template
//          Autowired the Rating Service
//        ResponseEntity<List<Rating>> ratings = this._ratingService.getRatingByUserID(userId);
//        List<Rating> ratingOfUser = ratings.getBody();

        List<Rating> ratingList = ratingOfUser.stream().peek(
                rating -> {
                    // api call to hotel service to get the hotel

                    ResponseEntity<Hotel> forEntity = this._hotelService.getHotel(rating.getHotelId());

                    logger.info("Status Code {}",forEntity.getStatusCode());
                    // set the hotel to rating
                    rating.setHotel(forEntity.getBody());
                    // return the rating
                }
        ).collect(Collectors.toList());

        logger.info("{}",ratingList);

        user.setRatings(ratingList);
        return user;
    }

    @Override
    public String deleteRecord(String userId) {
        User user = this._userRepository.findById(userId).orElse(null);
        if(user == null) {
            return "User With "+ userId+" Not Present ....";
        }
        else {
            this._userRepository.delete(user);
            return "User Deleted Successfully ....";
        }
    }

    @Override
    public String updateRecord(String userId, User user) {
        User findUser = this._userRepository.findById(userId).orElse(null);
        if(findUser == null) {
            return "User With "+ userId+" Not Present ....";
        }
        else {
            if(user.getName() != null && !user.getName().isBlank() && !user.getName().isEmpty())
                findUser.setName(user.getName());
            if(user.getEmail() != null && !user.getEmail().isBlank() && !user.getEmail().isEmpty())
                findUser.setEmail(user.getEmail());
            if(user.getAbout() != null && !user.getAbout().isBlank() && !user.getAbout().isEmpty())
                findUser.setAbout(user.getAbout());

            this._userRepository.save(findUser);
            return "User Updated Successfully ....";
        }
    }
}
