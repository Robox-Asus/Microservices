package com.user.userservice.controllers;

import com.user.userservice.entities.User;
import com.user.userservice.exception.UserNotFoundException;
import com.user.userservice.services.UserService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.extern.flogger.Flogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    private final UserService _userService;
    private final Logger logger = LoggerFactory.getLogger(UserService.class);
    public UserController(UserService userService) {
        this._userService = userService;
    }
    //create
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User saveUser = this._userService.saveUser(user);
        return (saveUser == null) ? ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null) : ResponseEntity.status(HttpStatus.CREATED).body(saveUser);
    }
    //getAllUser
    @PreAuthorize("hasAuthority('Admin')")
    @GetMapping
    public  ResponseEntity<List<User>> getAllUsers() {
        List<User> listOfUsers = this._userService.getAllUser();
        return ResponseEntity.ok(listOfUsers);
    }
    //getSingleUser
//    int retryCount = 1;
    @PreAuthorize("hasAuthority('Admin')")
    @GetMapping("/{userId}")
//    @CircuitBreaker(name = "ratingHotelBreaker",fallbackMethod = "ratingHotelFallback")
    // @Retry(name = "ratingHotelBreaker",fallbackMethod = "ratingHotelFallback")
    @RateLimiter(name = "userRateLimiter",fallbackMethod = "ratingHotelFallback")
    public  ResponseEntity<User> getUserById(@PathVariable String userId) {
        User user = this._userService.getUser(userId);

//        logger.info("Retry Count : {}"+retryCount);
//        retryCount++;
        return ResponseEntity.ok(user);
    }

    // creating fall back method for circuitbreaker
    public ResponseEntity<User> ratingHotelFallback(String userId,Exception ex) {
        ex.printStackTrace();
        logger.info("Fallback method is executed , Server is Down {} ",ex.getMessage());
        User user = User.builder().
                email("dummy@gmail.com").
                name("Dummy").
                about("This is an dummy id because server is down.").
                userId("123456").
                build();
        return new ResponseEntity<>(user,HttpStatus.OK);
    }

    //deleteUser
    @PreAuthorize("hasAuthority('Admin')")
    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable String userId) {
        String response = this._userService.deleteRecord(userId);
        return ResponseEntity.ok(response);
    }

    //updateUser
    @PreAuthorize("hasAuthority('Admin')")
    @PutMapping("/update/{userId}")
    public ResponseEntity<String> updateUser(@PathVariable String userId,@RequestBody User user) {
        String response = this._userService.updateRecord(userId,user);
        return ResponseEntity.ok(response);
    }
}
