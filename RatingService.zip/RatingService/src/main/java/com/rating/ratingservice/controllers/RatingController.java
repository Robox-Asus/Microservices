package com.rating.ratingservice.controllers;

import com.rating.ratingservice.Services.RatingService;
import com.rating.ratingservice.entities.Rating;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/ratings")
public class RatingController {

    private final RatingService _ratingService;

    public RatingController(RatingService ratingService) {
        this._ratingService = ratingService;
    }

    //create rating
    @PreAuthorize("hasAuthority('Admin')")
    @PostMapping
    public ResponseEntity<Rating> createRating(@RequestBody Rating rating) {
        return ResponseEntity.status(HttpStatus.CREATED).body(_ratingService.create(rating));
    }

    //getAll rating
    @GetMapping
    public ResponseEntity<List<Rating>> getRating() {
        return ResponseEntity.ok(_ratingService.getRatings());
    }

    //get Rating by User Id
    @PreAuthorize("hasAuthority('SCOPE_internal')")
    @GetMapping("/users/{userId}")
    public ResponseEntity<List<Rating>> getRatingByUserID(@PathVariable String userId) {
        return ResponseEntity.ok(_ratingService.userRating(userId));
    }

    //get Rating by Hotel ID
    @PreAuthorize("hasAuthority('SCOPE_internal') || hasAuthority('Admin')")
    @GetMapping("/hotels/{hotelId}")
    public ResponseEntity<List<Rating>> getHotelRating(@PathVariable String hotelId) {
        return ResponseEntity.ok(_ratingService.hotelRating(hotelId));
    }
}
