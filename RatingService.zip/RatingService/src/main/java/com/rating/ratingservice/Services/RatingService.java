package com.rating.ratingservice.Services;

import com.rating.ratingservice.entities.Rating;
import com.rating.ratingservice.interfaces.IRatingService;
import com.rating.ratingservice.repository.RatingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RatingService implements IRatingService {

    private final RatingRepository _ratingRepository;

    public RatingService(RatingRepository ratingRepository) {
        this._ratingRepository = ratingRepository;
    }

    @Override
    public Rating create(Rating rating) {
        return this._ratingRepository.save(rating);
    }

    @Override
    public List<Rating> getRatings() {
        return this._ratingRepository.findAll();
    }

    @Override
    public List<Rating> userRating(String userId) {
        return this._ratingRepository.findByUserId(userId);
    }

    @Override
    public List<Rating> hotelRating(String hotelId) {
        return this._ratingRepository.findByHotelId(hotelId);
    }
}
