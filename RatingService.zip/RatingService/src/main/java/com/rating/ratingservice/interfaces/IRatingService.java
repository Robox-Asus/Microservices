package com.rating.ratingservice.interfaces;

import com.rating.ratingservice.entities.Rating;

import java.util.List;

public interface IRatingService {

    //create
    Rating create(Rating rating);

    // get all ratings
    List<Rating> getRatings();

    //get rating by User
    List<Rating> userRating(String userId);

    //get rating by hotel
    List<Rating> hotelRating(String hotelId);

}
